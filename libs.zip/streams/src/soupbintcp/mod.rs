pub mod soupbintcp_client;
pub mod soupbintcp_packet;

// Re-export common types
pub use soupbintcp_client::ConnectionEvent;
