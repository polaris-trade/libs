use crate::ParseError;

pub type ParseResult<T> = Result<T, ParseError>;
